var express=require('express'); 
var app = express(),bodyParser = require("body-parser");;

const admin = require('firebase-admin');

var serviceAccount = require("./key.json");
var cors = require("cors");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://tecnologias-web-uaa-default-rtdb.firebaseio.com/"
});
app.use(bodyParser.json());
app.use(cors({origin:'*'}))
const firedb = admin.database()
/*************************  INSERT PRODUCTOS   ***********************/
app.post('/firebase-db',(req,res)=>{
	const newContact=req.query;
	firedb.ref("productos").push(newContact);
	res.send('recibido')
	});
	
app.get('/firebase-db',(req,res)=>{
	const newContact=req.query;
	firedb.ref("productos").push(newContact);
	res.send('recibido')
	});
	/**********************************************/



app.get('/firebase-cat',(req,res)=>{
	let r = req.query;
	const newContact={id:r.id,nombre:r.nombre,cant_prod:r.cant}
	firedb.ref(r.tabla).push(newContact);
	res.send('recibido')
	});
	
app.get('/firebase-get',(req,res)=>{
	firedb.ref(req.query.tabla).on("value",function(x){
	let xStr = JSON.stringify(x)
	res.send(xStr.replaceAll('"',"'").replaceAll("},'","}}-,-{\'").split("-,-"))
	})

});





app.listen(5555,() => console.log(`Listening on http://localhost:5555`))